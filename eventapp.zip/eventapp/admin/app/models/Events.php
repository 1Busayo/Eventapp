<?php

class Events {
    private $db;

public function __construct(){
    $this->db = new Database;
}




public function add_event($data){
    $this->db->query('INSERT INTO events (event_name , event_type , event_host , event_venue , event_desc,event_date,event_time) VALUES(:x1,:x2,:x3,:x4,:x5,:x6,:x7)');
    // Bind values
        $this->db->bind(':x1',$data['x1']);
		$this->db->bind(':x2',$data['x2']);
		$this->db->bind(':x3',$data['x3']);
		$this->db->bind(':x4',$data['x4']);
		$this->db->bind(':x5',$data['x5']);
		$this->db->bind(':x6',$data['x6']);
		$this->db->bind(':x7',$data['x7']);
		
      
        //Execute
      if($this->db->execute()){
          return true;
      } else{
          return false;
      }
    
}


public function update_event($data){
    $this->db->query('UPDATE events SET event_name =:x1 , event_type=:x2, event_host=:x3 ,event_venue=:x4 , event_desc=:x5 , event_date=:x6 , event_time=:x7  WHERE  events_id = :id ');
    // Bind values
	      $this->db->bind(':x1',$data['x1']);
		$this->db->bind(':x2',$data['x2']);
		$this->db->bind(':x3',$data['x3']);
		$this->db->bind(':x4',$data['x4']);
		$this->db->bind(':x5',$data['x5']);
		$this->db->bind(':x6',$data['x6']);
		$this->db->bind(':x7',$data['x7']);
        $this->db->bind(':id',$data['id']);
        
      
        //Execute
      if($this->db->execute()){
          return true;
      } else{
          return false;
      }
    
}


public function del_event($id){
    $this->db->query('DELETE FROM events WHERE  events_id = :id ');
    // Bind values
     $this->db->bind(':id',$id);
        //Execute
      if($this->db->execute()){
          return true;
      } else{
          return false;
      }
}



public function get_events(){
    $this->db->query('select * from events');
    $results = $this->db->resultSet();
    return $results;
}



public function get_events_by_id($id){
    $this->db->query('select *  from events where events_id =:id ');
	
	  $this->db->bind(':id',$id);
	  
    $row = $this->db->single();

return $row;
}



public function add_event_type($data){
    $this->db->query('INSERT INTO event_type (event_type_name) VALUES(:event_type_name)');
    // Bind values
        $this->db->bind(':event_type_name',$data['event_type_name']);
    
      
        //Execute
      if($this->db->execute()){
          return true;
      } else{
          return false;
      }
    
}

public function get_event_list(){
    $this->db->query('select * from event_type');
    $results = $this->db->resultSet();
    return $results;
}


public function get_event_type_by_id($id){
    $this->db->query('select event_type_name  from event_type where event_type_id =:id ');
	
	  $this->db->bind(':id',$id);
	  
    $row = $this->db->single();

return $row;
}





public function update_event_type($data){
    $this->db->query('UPDATE event_type SET event_type_name =:event_type_name   WHERE  event_type_id = :id ');
    // Bind values
        $this->db->bind(':id',$data['id']);
        $this->db->bind(':event_type_name',$data['event_type_name']);
      
        //Execute
      if($this->db->execute()){
          return true;
      } else{
          return false;
      }
    
}

public function del_event_type($id){
    $this->db->query('DELETE FROM event_type WHERE  event_type_id = :id ');
    // Bind values
     $this->db->bind(':id',$id);
        //Execute
      if($this->db->execute()){
          return true;
      } else{
          return false;
      }
}



public function get_total($typ ){
    $con = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
    
    // Check connection
    if (mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      exit();
    }else{
   
        if($typ === 'x1'){
$q1 = mysqli_query($con ,"SELECT count(*) as total_request FROM event_type ");
$qx1 = mysqli_fetch_array($q1);
$x1 = $qx1['total_request'];
return $x1;
        } elseif( $typ === 'x2'){
            $q1 = mysqli_query($con ,"SELECT count(*) as total_request FROM events ");
$qx1 = mysqli_fetch_array($q1);
$x2 = $qx1['total_request'];
return $x2;
        }elseif( $typ === 'x3'){
            $q1 = mysqli_query($con ,"SELECT count(*) as total_request FROM apply_event ");
$qx1 = mysqli_fetch_array($q1);
$x3 = $qx1['total_request'];
return $x3;
        }



    }

}



}