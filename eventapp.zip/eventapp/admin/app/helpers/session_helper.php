<?php
session_start();

//Flash message helper
//Example - flash('register_success','You are now registered');
//DISPLAY IN VIEW - echo flash('register_success');
 function flash($name='',$message='', $class='alert alert-success'){
if(!empty($name)){
if(!empty($message) && empty($_SESSION[$name])){

if(!empty($_SESSION[$name])){
  unset($_SESSION[$name]);
}

if(!empty($_SESSION[$name.'_class'])){
    unset($_SESSION[$name.'_class']);
  }
  

    $_SESSION[$name] = $message;
    $_SESSION[$name.'_class'] = $class;
}elseif(empty($message) && !empty($_SESSION[$name])){
 $class = !empty($_SESSION[$name.'_class']) ? $_SESSION[$name.'_class'] : '';
 echo '<div class="'.$class.'"  id="msg-flash">'.$_SESSION[$name].'</div>';
 unset($_SESSION[$name]);
 unset($_SESSION[$name.'_class']);
}
}
}


function alert_suc(){
  echo '<div class="col-md-6 alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong><i class="fa fa-check-circle" aria-hidden="true"></i>   submitted successfully  !</strong> </div>';
}

function alert_info($msg){
  echo '<div class="col-md-6 alert alert-primary alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong><i class="fa fa-info-circle" aria-hidden="true"></i> '.$msg .' !</strong> </div>';
}


 function  isLoggedIn(){
  if(isset($_SESSION['user_id'])){
      return true;
  }else{
      return false;
  }
}
