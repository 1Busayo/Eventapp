<?php
//simple page redirect

function li_page_helper(){
   
     echo  $active = 'class="active"';
   
    
    
    }


    function ul_page_helper(){
       
         echo "show";
       
        
        
        }