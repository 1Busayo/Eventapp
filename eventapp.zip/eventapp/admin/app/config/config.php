<?php
//DB params
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','event_app');

//APP ROOT
define ('APPROOT' ,  dirname(dirname( __FILE__)));
//SITE ROOT
define ('SITE_ROOT', realpath(dirname(__FILE__)));
//URL Root http://localhost/phpthunder
define('URLROOT', 'http://'.$_SERVER['HTTP_HOST'].'/eventapp/admin');
//Site Name
define('SITENAME', 'Events App');
define('APP_NAME', 'Events App');
//APP VERSION
define('APPVERSION', '1.0.0');
