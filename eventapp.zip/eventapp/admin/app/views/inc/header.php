<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title><?php echo SITENAME; ?> </title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
    <link href="<?php echo URLROOT; ?>/assets/css/loader.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo URLROOT; ?>/assets/js/loader.js"></script>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="<?php echo URLROOT; ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo URLROOT; ?>/assets/css/plugins.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
    <link href="<?php echo URLROOT; ?>/plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
    <link href="<?php echo URLROOT; ?>/assets/css/dashboard/dash_1.css" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
    <script src="https://kit.fontawesome.com/bd53529781.js" crossorigin="anonymous"></script>

    <!-- BEGIN PAGE LEVEL CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/plugins/table/datatable/datatables.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/assets/css/forms/theme-checkbox-radio.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/plugins/table/datatable/dt-global_style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/plugins/table/datatable/custom_dt_custom.css">
    <!-- END PAGE LEVEL CUSTOM STYLES -->

      <!--  BEGIN CUSTOM STYLE FILE  -->
      <link href="<?php echo URLROOT; ?>/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo URLROOT; ?>/assets/css/components/custom-modal.css" rel="stylesheet" type="text/css" />
    <!--  END CUSTOM STYLE FILE  -->
</head>
<body>
  <!-- BEGIN LOADER -->
  <div id="load_screen"> <div class="loader"> <div class="loader-content">
        <div class="spinner-grow align-self-center"></div>
    </div></div></div>
    <!--  END LOADER -->

       <!--   NAVBAR  -->
       <?php require APPROOT.'/views/inc/navbar.php'; ?>

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">


    <div class="overlay"></div>
    <div class="search-overlay"></div>


    <!--  BEGIN SIDEBAR  -->
    <?php require APPROOT.'/views/inc/sidebar.php'; ?>

    <!--  END SIDEBAR  -->
  