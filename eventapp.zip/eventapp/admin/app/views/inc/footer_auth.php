    
    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo URLROOT; ?>/assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="<?php echo URLROOT; ?>/bootstrap/js/popper.min.js"></script>
    <script src="<?php echo URLROOT; ?>/bootstrap/js/bootstrap.min.js"></script>
    
    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo URLROOT; ?>/assets/js/authentication/form-2.js"></script>

</body>
</html>