<?php require APPROOT.'/views/inc/header.php'; ?>

        
        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">
           
                <div class="row layout-top-spacing">


                </div>
            

            
          
                   
                        <div id="" class="col-lg-12 layout-spacing col-md-12">
                        <?php if( !empty($_GET['alt']) && $_GET['alt'] === '1'){ 
                            alert_suc();
                       }    
                          ?>
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>Settings</h4>
                                        </div>                 
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">
                                <form action="<?php echo URLROOT;?>/auth/setting" method="POST" autocomplete="off">

                              <?php  $user = $data['user'] ;?>

   
                                                <div class="form-row"> 
                                            <div class="col-md-4 mb-4">
                                                <label for="validationDefault02">Name</label>
                                                <input type="text" name="name" class="form-control form-control-lg <?php echo (!empty($data['name_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $user->name; ?>" required>
                                    <span class="invalid-feedback"><?php echo $data['name_err']; ?></span>
                                            </div>
											
                                             </div>
                                             
                                             <div class="form-row"> 
                                            <div class="col-md-4 mb-4">
                                                <label for="validationDefault02">Email</label>
                                                
                                                <input type="email" name="email" class="form-control  <?php echo (!empty($data['email_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $user->email;  ?>"  required>
                                                <span class="invalid-feedback"><?php echo $data['email_err']; ?></span>

                                            </div>
											
											 </div>

                                                
                                             <div class="form-row"> 
                                            <div class="col-md-4 mb-4">
                                        <label for="password">Change Password</label>
                                     
                                   <input type="password" name="password" class="form-control form-control-lg <?php echo (!empty($data['password_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['password']; ?>" autocomplete="new-password">
                                     <span class="invalid-feedback"><?php echo $data['password_err']; ?></span>

                               </div>
                                   </div>



                                   <div class="form-row"> 
                                            <div class="col-md-4 mb-4">
                                        <label for="confirm_password">Confirm Password</label>
                                    <input type="password" name="confirm_password" class="form-control form-control-lg <?php echo (!empty($data['confirm_password_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['confirm_password']; ?>">
                                  <span class="invalid-feedback"><?php echo $data['confirm_password_err']; ?></span>

                                 </div>

                                      
                                                </div>
                                       
                                      
                                      <button class="btn btn-primary mt-3" type="submit">Update </button>
                                    </div> 
									</form>

                                  
                                </div>
                            </div>
                        </div>
                    
        <!--  END CONTENT PART  -->

    
    <!-- END MAIN CONTAINER -->

       <?php require APPROOT.'/views/inc/footer.php'; ?>