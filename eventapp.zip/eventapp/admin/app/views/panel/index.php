<?php require APPROOT.'/views/inc/header.php'; ?>
  
 
        
        <!--  BEGIN CONTENT AREA  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">

                <div class="row layout-top-spacing">

                
               
				 
				 <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12 layout-spacing">
                        <div style=" background: #28a745;" class="widget widget-">
                            <div class="widget-content">

                                <div class="header">
                                    <div  class="header-body">
                                        <h3 style="color: #fff;">Event Type</h3>
                                        <h4  style="color: #fff;" class="meta-date"><?php echo $data['x1']; ?></h4>
                                    </div>
                           
                                </div>

                            
                            </div>
                        </div>

                    </div>

			 
				 <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12 layout-spacing">
                        <div style=" background: #007afc;" class="widget widget-">
                            <div class="widget-content">

                                <div class="header">
                                    <div  class="header-body">
                                        <h3 style="color: #fff;">Scheduled Events</h3>
                                        <h4  style="color: #fff;" class="meta-date"><?php echo $data['x2']; ?></h4>
                                    </div>
                           
                                </div>

                            
                            </div>
                        </div>

                    </div>

			 
				 <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12 layout-spacing">
                        <div style=" background: #6c757d;" class="widget widget-">
                            <div class="widget-content">

                                <div class="header">
                                    <div  class="header-body">
                                        <h3 style="color: #fff;">Applicants</h3>
                                        <h4  style="color: #fff;" class="meta-date"><?php echo $data['x3']; ?></h4>
                                    </div>
                           
                                </div>

                            
                            </div>
                        </div>

                    </div>

	

			
 </div>

            </div>
          
    <?php require APPROOT.'/views/inc/footer.php'; ?>