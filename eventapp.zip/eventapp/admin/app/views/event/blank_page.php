<?php require APPROOT.'/views/inc/header.php'; ?>

        
        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">

                <div class="row layout-top-spacing">


                </div>

            </div>
          
        <!--  END CONTENT PART  -->

    
    <!-- END MAIN CONTAINER -->

       <?php require APPROOT.'/views/inc/footer.php'; ?>