<?php require APPROOT.'/views/inc/header.php'; ?>

        
        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">
        
                <div class="row layout-top-spacing">
      </div>

              
                
                        <div id="" class="col-lg-12 layout-spacing col-md-12">
                        <?php if( !empty($_GET['alt']) && $_GET['alt'] === '1'){ 
                            alert_suc();
                       }    
                          ?>
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>Edit Event type</h4>
                                        </div>                 
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">

                                
                                <form action="<?php echo URLROOT;?>/event/edit_event_type/<?php echo  $data['event_by_id']; ?>" method="POST">

                                        <div class="form-row">
                                     
                                                </div>
                                                <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Event Type Name</label>
                                                <input type="text" class="form-control" name="x1" placeholder="Enter Event Type Name" value="<?php echo $data['event_by_name']->event_type_name ; ?>" required>
                                            </div>
											 </div>
                                               
                                            
                                      
                                      <button class="btn btn-primary mt-3" type="submit">Edit </button>
                                    </div> 
									</form>

                                  
                                </div>
                            </div>
							
							
               
							
                        </div>
                    
        <!--  END CONTENT PART  -->

    
    <!-- END MAIN CONTAINER -->

       <?php require APPROOT.'/views/inc/footer.php'; ?>