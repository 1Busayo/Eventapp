<?php require APPROOT.'/views/inc/header.php'; ?>

        
        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">
        
                <div class="row layout-top-spacing">
      </div>

              
                
                        <div id="" class="col-lg-12 layout-spacing col-md-12">
                        <?php if( !empty($_GET['alt']) && $_GET['alt'] === '1'){ 
                            alert_suc();
                       } 
					  if( !empty($_GET['alt']) && $_GET['alt'] === '2'){ 
                            alert_info('Deleted succesfully');
                       }    
                          ?>
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>Add Event type</h4>
                                        </div>                 
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">

                                
                                <form action="<?php echo URLROOT;?>/event/add_event_type" method="POST">

                                        <div class="form-row">
                                     
                                                </div>
                                                <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Event Type Name</label>
                                                <input type="text" class="form-control" name="x1" placeholder="Enter Event Type Name"  required>
                                            </div>
											 </div>
                                               
                                            
                                      
                                      <button class="btn btn-primary mt-3" type="submit">Submit </button>
                                    </div> 
									</form>

                                  
                                </div>
                            </div>
							
							<hr>
							
							
							   <div class="row layout-top-spacing layout-spacing">
                    <div class="col-lg-12">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>List Of Event type</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="table-responsive mb-4">
                                    <table id="style-3" class="table style-3  table-hover non-hover">
                                        <thead>
                                            <tr>
                                              
                                                <th>Event ID </th>
                                                <th>Event Type</th>
                                                <th>Edit</th>
                                                
                                                <th class="text-center">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php  foreach($data['event_list'] as $event_list) :   ?>
                                            <tr>
                                               
                                                <td><?php echo $event_list->event_type_id; ?></td>
                                                <td><?php echo $event_list->event_type_name; ?></td>
                                              
                                            <td><a class="dropdown-item"  href="<?php echo URLROOT .'/event/edit_event_type/'.$event_list->event_type_id;?>"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-3"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg></a></td>
                                            <td><a class="dropdown-item"  href="<?php echo URLROOT .'/event/event_type_delete/'.$event_list->event_type_id;?>"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg></a></td>
                                           
                                           
                                            </tr> 
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

               
							
                        </div>
                    
        <!--  END CONTENT PART  -->

    
    <!-- END MAIN CONTAINER -->

       <?php require APPROOT.'/views/inc/footer.php'; ?>