<?php require APPROOT.'/views/inc/header.php'; ?>

        	<?php 
							
							function get_name($patx_id){
    $con = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
    
    // Check connection
    if (mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      exit();
    }else{

$q1 = mysqli_query($con ,"SELECT event_type_name FROM event_type where event_type_id='$patx_id'");
$qx1 = mysqli_fetch_array($q1);
$x1 = $qx1['event_type_name'];
return $x1;
       
        }
							}
							
							?>
        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">
        
                <div class="row layout-top-spacing">
      </div>

              
                
                        <div id="" class="col-lg-12 layout-spacing col-md-12">
                        <?php if( !empty($_GET['alt']) && $_GET['alt'] === '1'){ 
                            alert_suc();
                       }    
                          ?>
                       
                            </div>
							
                            <div class="statbox widget box box-shadow">
                                <div class="widget-header">
                                    <div class="row">
                                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                            <h4>Edit Event</h4>
                                        </div>                 
                                    </div>
                                </div>
                                <div class="widget-content widget-content-area">

                                
                                <form action="<?php echo URLROOT;?>/event/edit_event/<?php echo $data["event_edit"]->events_id ;?>" method="POST">

                                        <div class="form-row">
                                     
                                                </div>
                                                <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Event Name</label>
                                                <input type="text" class="form-control" name="x1" placeholder="Enter Event Name" value="<?php echo $data["event_edit"]->event_name; ?>" required>
                                            </div>
											 </div>
											 
                                               <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Event Type</label>
                                                
												 <select class="form-control" autocomplete="no" name="x2"  required>
                                                <option value="<?php echo $data["event_edit"]->event_type;?>" selected><?php echo get_name($data["event_edit"]->event_type); ?></option>
												    <?php  foreach($data['list_type'] as $list) :   ?>
                                                <option value="<?php echo $list->event_type_id;?>"><?php echo $list->event_type_name;?></option>
												  <?php endforeach; ?>
                                               </select>
                                            </div>
											 </div>
                                               
                                             <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Host</label>
                                                <input type="text" class="form-control" name="x3" placeholder="Enter Host" value="<?php echo $data["event_edit"]->event_host; ?>"  required>
                                            </div>
											 </div>
											 <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Venue</label>
                                                <input type="text" class="form-control" name="x4" placeholder="Enter Venue" value="<?php echo $data["event_edit"]->event_venue; ?>"  required>
                                            </div>
											 </div>
                                               	 <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Description</label>
                                                <textarea class="form-control" name="x5" placeholder="Enter Description"><?php echo $data["event_edit"]->event_desc; ?></textarea>  
                                            </div>
											 </div>
											 
											 	 <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Date</label>
                                                <input type="date" class="form-control" name="x6" placeholder="Enter Date" value="<?php echo $data["event_edit"]->event_date; ?>"  required>
                                            </div>
											 </div>
											 
											 	 <div class="form-row">                    
                                                        <div class="col-md-4 mb-4">
                                                <label for="validationDefault01">Time</label>
                                                <input type="time" class="form-control" name="x7" placeholder="Enter Time" value="<?php echo $data["event_edit"]->event_time; ?>"  required>
                                            </div>
											 </div>
                                               
                                            
                                      
                                      <button class="btn btn-primary mt-3" type="submit">Edit Event </button>
                                    </div> 
									</form>

                                  
                                </div>
                            
               
							
                        </div>
                    
        <!--  END CONTENT PART  -->

    
    <!-- END MAIN CONTAINER -->

       <?php require APPROOT.'/views/inc/footer.php'; ?>