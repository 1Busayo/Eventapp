<?php

class Auth extends Controller {

    public function __construct(){

        // if (isLoggedIn()){
     
        //     redirect('panel');  
        //   }

     $this->userModel = $this->model('User');
    }

//login function
    public function index(){

      //check for POST
  if($_SERVER['REQUEST_METHOD'] == 'POST'){
  //Process form
  
  //Sanitize POST data
  $_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);
  
    //Init data
    $data=[
      
      'email' => trim($_POST['email']),
      'password' => trim($_POST['password']),
      'email_err' => '',
      'password_err' => ''
      
  ];
  
   //Validate Email
   if(empty($data['email'])){
      $data['email_err'] = 'Please enter email';
      }
      
   //Validate Password
   if(empty($data['password'])){
      $data['password_err'] = 'Please enter password';
      }
  
      //check for user/email
      if($this->userModel->findUserByEmail($data['email'])){
     //User found
  
      } else {
          //User not found 
          $data['email_err'] = 'No user found';
      }
  
    //Make sure errors are empty
    if(empty($data['email_err'])   && empty($data['password_err'])){
      //validated
  //check and set logged in user
  $loggedInUser = $this->userModel->login($data['email'],$data['password']);
  
  if($loggedInUser){
  //create session
  
  $this->createUserSession($loggedInUser);
  
  } else{
      $data['password_err'] = 'Password incorrect';
      $this->view('auth/index',$data);
  }
  
  } else {
      //Load view with errors
      $this->view('auth/index',$data);
  }
  
  
  }else{
      //Load form
    //Init data
    $data=[
      
        'email' => '',
        'password' => '',
        'email_err' => '',
        'password_err' => ''
       
    ];
  //Load view
  $this->view('auth/index',$data);
  
    
  }
  
  }
  

  public function register(){

    //check for POST
if($_SERVER['REQUEST_METHOD'] == 'POST'){
//Process form

//Sanitize POST data
$_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

  //Init data
  $data=[
    'name' => trim($_POST['name']),
    'email' => trim($_POST['email']),
    'password' => trim($_POST['password']),
    'confirm_password' => trim($_POST['confirm_password']),
    'acct_type' => 'C',
    'name_err' => '',
    'email_err' => '',
    'password_err' => '',
    'confirm_password_err' => ''
];

 //Validate Email
if(empty($data['email'])){
$data['email_err'] = 'Please enter email';
}else {
    //check email
    if($this->userModel->findUserByEmail($data['email'])){

        $data['email_err'] = 'Email is already taking';  

    }
}

//Validate Name
if(empty($data['name'])){
    $data['name_err'] = 'Please enter name';
    }

//Validate Confirm Password
    if(empty($data['confirm_password'])){
        $data['confirm_password_err'] = 'Please confirm password';
        } else {
        if($data['password'] != $data['confirm_password']) {
        $data['confirm_password_err'] = 'Pasword  do not match';
        }
    }


//Validate Password
if(empty($data['password'])){
    $data['password_err'] = 'Please enter password';
    }elseif(strlen($data['password']) < 6){
    $data['password_err'] = 'Pasword must be at least 6 characters';
    }

    
  //Make sure errors are empty
  if(empty($data['email_err']) && empty($data['name_err'])   && empty($data['password_err']) && empty($data['confirm_password_err'])  ){
    //validated
   //die('SUCCESS');

//Hash password
$data['password'] = password_hash($data['password'] , PASSWORD_DEFAULT);

//Register User

if($this->userModel->register($data)){
 //flash('register_success', 'You are registered and can login');   
redirect('auth/login');
}else{
    die('Something went wrong');
}

} else {
    //Load view with errors
    $this->view('auth/register',$data);
}




}else{
    //Load form
  //Init data
  $data=[
      'name' => '',
      'email' => '',
      'password' => '',
      'confirm_password' => '',
      'name_err' => '',
      'email_err' => '',
      'password_err' => '',
      'confirm_password_err' => ''
  ];
//Load view
$this->view('auth/register',$data);

  
}

}



 
public function setting(){

    //check for POST
if($_SERVER['REQUEST_METHOD'] == 'POST'){
//Process form

//Sanitize POST data
$_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

  
$id = $_SESSION['user_id'];
$user_details = $this->userModel->getUserById($id);
$data=[
  'li'=>'',
  'ul'=>'',
  'id'=> $id, 
  'user' =>  $user_details,
    'name' => trim($_POST['name']),
    'email' => trim($_POST['email']),
    'password' => trim($_POST['password']),
    'confirm_password' => trim($_POST['confirm_password']),
    'acct_type' => 'C',
    'name_err' => '',
    'email_err' => '',
    'password_err' => '',
    'confirm_password_err' => ''
];

 //Validate Email
if(empty($data['email'])){
$data['email_err'] = 'Please enter email';
}else {
    //check email
    if($this->userModel->findUserByEmail($data['email']) && $_SESSION['user_email'] !==  $data['email']  ){

        $data['email_err'] = 'Email '.$data['email'].' is already taking';  

    }
}

//Validate Name
if(empty($data['name'])){
    $data['name_err'] = 'Please enter name';
    }



//Validate Password
if(!empty($data['password'])){
   
    if(strlen($data['password']) < 6){
    $data['password_err'] = 'Pasword must be at least 6 characters';
    } elseif($data['password'] != $data['confirm_password']) {
        $data['confirm_password_err'] = 'Pasword  do not match';
        } else {


//Hash password
$data['password'] = password_hash($data['password'] , PASSWORD_DEFAULT);


        }
    }
    
  //Make sure errors are empty
  if(empty($data['email_err']) && empty($data['name_err']) && empty($data['password_err']) && empty($data['confirm_password_err'])   ){
    //validated
   //die('SUCCESS');

//Register User

if($this->userModel->setting($data)){
 //flash('register_success', 'You are registered and can login');   
redirect('auth/setting?alt=1');
}else{
    die('Something went wrong');
}

} else {
    //Load view with errors
    $this->view('auth/setting',$data);
}




}else{
    //Load form
  //Init data

  $id = $_SESSION['user_id'];
  $user_details = $this->userModel->getUserById($id);
  $data=[
    'li'=>'',
    'ul'=>'', 
    'user' =>  $user_details,
      'name' => '',
      'email' => '',
      'password' => '',
      'confirm_password' => '',
      'name_err' => '',
      'email_err' => '',
      'password_err' => '',
      'confirm_password_err' => ''
  ];
//Load view
$this->view('auth/setting',$data);

  
}

}

//forget password

   public function fg(){

      //check for POST
  if($_SERVER['REQUEST_METHOD'] == 'POST'){
  //Process form
  
  //Sanitize POST data
  $_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);
  
    //Init data
    $data=[
      
      'email' => trim($_POST['email']),
    'email_err' => ''
    
      
  ];
  
   //Validate Email
   if(empty($data['email'])){
      $data['email_err'] = 'Please enter email';
      }
      

  
      //check for user/email
      if($this->userModel->findUserByEmail($data['email'])){
     //User found

     // send reset password email
  
      } else {
          //User not found 
          $data['email_err'] = 'No user found';
          $this->view('auth/fg',$data);
      }
  
  
  
  
  }else{
      //Load form
    //Init data
    $data=[
      
        'email' => '',
         'email_err' => ''
       
       
    ];
  //Load view
  $this->view('auth/fg',$data);
  
    
  }
  
  }

public function createUserSession($user){
$_SESSION['user_id'] = $user->id;
$_SESSION['user_email'] = $user->email;
$_SESSION['user_name'] = $user->name;
redirect('panel');
}
public function logout(){
    unset($_SESSION['user_id']);
    unset($_SESSION['user_email']);
    unset($_SESSION['user_name']);
   session_destroy();
   redirect('auth/index');
}



}

?>