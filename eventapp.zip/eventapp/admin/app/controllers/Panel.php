<?php

class Panel extends Controller {

public function __construct(){
if (!isLoggedIn()){
     
  redirect('auth/index');  
}

 $this->userModel = $this->model('User');
 $this->eventModel = $this->model('Events');

}

//dashboard
    public function index(){
        
  
       $x1 = $this->eventModel->get_total('x1' );
       $x2 = $this->eventModel->get_total('x2' );
       $x3 = $this->eventModel->get_total('x3' );
      
      
        $data = [
        'li'=>'sales',
         'ul'=>'dashboard' ,
         'x1'=> $x1,
         'x2'=> $x2,
         'x3'=> $x3
        ];
        $this->view('panel/index',$data);
    }


}