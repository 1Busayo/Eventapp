<?php

class Event extends Controller {

public function __construct(){
if (!isLoggedIn()){
     
  redirect('auth/index');  
}

 $this-> eventModel = $this->model('Events');

}


    public function add_event(){
        
            
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
          //Sanitixe Post array

          $_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

           
           
          $data = [
            'x1'=>trim($_POST['x1']),
			'x2'=>trim($_POST['x2']),
			'x3'=>trim($_POST['x3']),
			'x4'=>trim($_POST['x4']),
			'x5'=>trim($_POST['x5']),
			'x6'=>trim($_POST['x6']),
			'x7'=>trim($_POST['x7'])
			
       ];
      

        
        if($this->eventModel->add_event($data)){
     
        redirect('event/add_event?alt=1');
        } else{
        die('Something went wrong');
        }
          

          } else { 
            
			  $list_type = $this->eventModel->get_event_list();
              $list_events = $this->eventModel->get_events();
              
  

   $data = [
                'li'=>'add_event',
                'ul'=>'event',
				'list_type' => $list_type,
				'list_events' => $list_events
							
                ];
  
			
          $this->view('event/add_event',$data);
          }
            
        
    }  


 	public function edit_event($id){
        
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
          //Sanitixe Post array

          $_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);
     $data = [
            'x1'=>trim($_POST['x1']),
			'x2'=>trim($_POST['x2']),
			'x3'=>trim($_POST['x3']),
			'x4'=>trim($_POST['x4']),
			'x5'=>trim($_POST['x5']),
			'x6'=>trim($_POST['x6']),
			'x7'=>trim($_POST['x7']),
			'id' => $id
       ];
         
      

        
        if($this->eventModel->update_event($data)){
     
        redirect('event/add_event?alt=1');
        } else{
        die('Something went wrong');
        }
          

          } else { 
            
			  $event_by_id	 = $this->eventModel->get_events_by_id($id);
              $list_type = $this->eventModel->get_event_list();

   $data = [
                'li'=>'add_event',
                'ul'=>'event',
				'list_type' => $list_type,
				'event_edit' => $event_by_id,			
                'events_id' => $id			
                ];
  
			
          $this->view('event/edit_event',$data);
          }
            
        
    }




public function event_delete($id){
 
$this->eventModel->del_event($id);

 redirect('event/add_event?alt=2');


}




   public function add_event_type(){
        
            
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
          //Sanitixe Post array

          $_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

          $data = [
            'event_type_name'=>trim($_POST['x1'])
       ];
      

        
        if($this->eventModel->add_event_type($data)){
     
        redirect('event/add_event_type?alt=1');
        } else{
        die('Something went wrong');
        }
          

          } else { 
            
			  $event_list = $this->eventModel->get_event_list();
  

   $data = [
                'li'=>'add_event_type',
                'ul'=>'event',
				'event_list' => $event_list				
                ];
  
			
          $this->view('event/add_event_type',$data);
          }
            
        
    }  


	public function edit_event_type($id){
        
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
          //Sanitixe Post array

          $_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

          $data = [
            'event_type_name'=>trim($_POST['x1']),
			'id' => $id
			
       ];
      

        
        if($this->eventModel->update_event_type($data)){
     
        redirect('event/add_event_type?alt=1');
        } else{
        die('Something went wrong');
        }
          

          } else { 
            
			  $event_by_id	 = $this->eventModel->get_event_type_by_id($id);
  

   $data = [
                'li'=>'add_event_type',
                'ul'=>'event',
				'event_by_name' => $event_by_id,			
                'event_by_id' => $id			
                ];
  
			
          $this->view('event/edit_event_type',$data);
          }
            
        
    }



public function event_type_delete($id){
 
$this->eventModel->del_event_type($id);

 redirect('event/add_event_type?alt=2');


}



public function pop($req_id) {


  if($_SERVER['REQUEST_METHOD'] == 'POST'){
  //Sanitixe Post array

  $_POST = filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);


      $errors= array();
      $file_name = $_FILES['x1']['name'];
      $file_size =$_FILES['x1']['size'];
      $file_tmp =$_FILES['x1']['tmp_name'];
      $file_type=$_FILES['x1']['type'];
      $tnx = explode('.',$file_name);
      $file_ext=strtolower(end($tnx));
      
      $extensions= array("jpeg","jpg","png","pdf");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG ,PDF and PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      $filex_loc= dirname(APPROOT);
      if(empty($errors)==true){
        
        $temp = explode(".",$file_name);
        $newfilename = round(microtime(true)) . '.' . end($temp);


         move_uploaded_file($file_tmp,$filex_loc."/public/pop/".$_SESSION['user_id'].'_'.$newfilename);

         $data = [
           id =>$req_id,
           'url'=> URLROOT."/pop/".$_SESSION['user_id'].'_'.$newfilename
         ];

         $this->eventModel->pop($data);
          echo "Success";

         redirect('/truck/view_request');

   } elseif(!empty($errors)) { 
   //Get existig post from model
$truck_request = $this->eventModel->getrequestById($req_id);

$err = $errors[0];


    $data = [
      'li'=>'view_request',
      'ul'=>'truck',
	   'truckrequest'=>$truck_request ,
       'errors'=> $err	  
    ];

     
   //Load view with errors
   $this->view('truck/pop',$data);
  }
   


} else { 



 //Get existig post from model
$truck_request = $this->eventModel->getrequestById($req_id);



$data = [
  'li'=>'view_request',
  'ul'=>'truck',  
  'truckrequest'=>$truck_request   
];


     $this->view('truck/pop',$data);

}

}



  

}