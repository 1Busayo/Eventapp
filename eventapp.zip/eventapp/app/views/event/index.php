<?php require APPROOT.'/views/inc/header.php'; ?>

        
        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">
        
                <div class="row layout-top-spacing">
      </div>

              
                
							<?php 
							
							function get_name($patx_id){
    $con = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
    
    // Check connection
    if (mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      exit();
    }else{

$q1 = mysqli_query($con ,"SELECT event_type_name FROM event_type where event_type_id='$patx_id'");
$qx1 = mysqli_fetch_array($q1);
$x1 = $qx1['event_type_name'];
return $x1;
       
        }
							}
							
							?>
							
							   <div class="row layout-top-spacing layout-spacing">
							     <?php if( !empty($_GET['alt']) && $_GET['alt'] === '1'){ 
                           alert_info('Event has been booked successfully');
                       }    
                          ?>
                       
							  
                    <div class="col-lg-12">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>List Of Event type</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="table-responsive mb-4">
                                    <table id="style-3" class="table style-3  table-hover non-hover">
                                        <thead>
                                            <tr>
                                              
                                                <th>Event Name </th>
                                                <th> Type</th>
                                                 <th> Host</th>
                                                <th> Venue</th>
                                                <th> Description</th>
                                                <th> Date</th>
                                                <th>Time</th>
                                                <th>Apply</th>
                                                
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php  foreach($data['list_events'] as $list_events) :   ?>
                                            <tr>
                                               
                                                <td><?php echo $list_events->event_name; ?></td>
                                                <td><?php echo get_name($list_events->event_type); ?></td>
                                               <td><?php echo $list_events->event_host; ?></td>
                                               <td><?php echo $list_events->event_venue; ?></td>
                                               <td><?php echo $list_events->event_desc; ?></td>
                                               <td><?php echo $list_events->event_date; ?></td>
                                              <td><?php echo $list_events->event_time; ?></td>
                                              
                                            <td><a class="dropdown-item"  href="<?php echo URLROOT .'/event/apply_event/'.$list_events->events_id;?>">Apply <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-3"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg></a></td>
                                            
                                           
                                            </tr> 
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

               
							
                        </div>
                    
        <!--  END CONTENT PART  -->

    
    <!-- END MAIN CONTAINER -->

       <?php require APPROOT.'/views/inc/footer.php'; ?>